var szoveg:string="Szeretem a programozást";
var szam:number=21;
var logikai:boolean=false;
