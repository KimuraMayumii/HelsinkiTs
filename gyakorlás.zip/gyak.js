var szoveg = "Szeretem a programozást";
var szam = 21;
var logikai = false;
